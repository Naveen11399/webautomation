package testCaes;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;
import org.apache.logging.log4j.Logger;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import pageObjects.LoginPageObj;
import utils.Helper;
import utils.ReadConfig;

public class BaseClass {

	public static WebDriver driver;
	ReadConfig rc = new ReadConfig();

	public String SchoolUrl = rc.getSchoolUrl();
	public String SchoolCode = rc.getSchoolCode();
	public String Username = rc.getUsername();
	public String Password = rc.getPassword();
	public LoginPageObj lp;
	public static Logger log;
	public static ExtentReports extentReports;
	public static ExtentTest extentTest;

	@BeforeSuite
	public void setupReport() {
		// Initialize the Spark reporter
		ExtentSparkReporter sparkReporter = new ExtentSparkReporter(
				new File(System.getProperty("user.dir") + "/reports/Izome_Report" + Helper.getTime() + ".html"));

		// Initialize ExtentReports and attach the Spark reporter
		extentReports = new ExtentReports();
		extentReports.attachReporter(sparkReporter);
	}

	@AfterMethod
	public void report(ITestResult result) throws IOException {
		// Get the current test method
//		extentTest = extentReports.createTest(result.getMethod().getMethodName());

		if (result.getStatus() == ITestResult.FAILURE) {
			extentTest.fail("Test Case Failed",
					MediaEntityBuilder.createScreenCaptureFromPath(Helper.Screenshot(driver)).build());
		} else if (result.getStatus() == ITestResult.SUCCESS) {
			extentTest.pass("Test Case Passed",
					MediaEntityBuilder.createScreenCaptureFromPath(Helper.Screenshot(driver)).build());
		}

		extentReports.flush(); // Ensure the report is written after each method
	}

	@BeforeClass
	public void setupBrowser() {

		log = LogManager.getLogger(this.getClass());

		if (rc.getBrowser().equals("Chrome")) {

			driver = new ChromeDriver();
			driver.get(SchoolUrl);
			driver.manage().window().maximize();
			driver.manage().deleteAllCookies();
			driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		}

		else if (rc.getBrowser().equals("Edge")) {
			driver = new EdgeDriver();

		} else if (rc.getBrowser().equals("FireFox")) {
			driver = new FirefoxDriver();

		}

	}

	@Test
	public void schoolLogin() throws InterruptedException {

		driver.get(SchoolUrl);
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		
		
		log.info("Test Start");
		lp = new LoginPageObj(driver);
		extentTest = extentReports.createTest("Test Start");
		
		lp.schoolCode(SchoolCode);
		lp.submitBtn();
		Thread.sleep(2000);
		lp.SchoolCodeToastVerify();
		extentTest.pass("School Code Verified");
		log.info("School Code Verified");
		
		lp.UserID(Username);
		lp.Password(Password);
		lp.LOGINBtn();
		log.info("LoggedIn Successfully");
		extentTest.pass("LoggedIn Successfully");

	}
}
