package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class LoginPageObj {
	WebDriver driver;

	public LoginPageObj(WebDriver ldriver) {
		driver = ldriver;
		PageFactory.initElements(ldriver, this);

	}

	@FindBy(xpath = "//input[@placeholder='School code']")
	@CacheLookup
	WebElement schoolCodeInput;

	@FindBy(xpath = "//button[normalize-space(text())='Submit']")
	@CacheLookup
	WebElement submitBtn;

	@FindBy(xpath = "//div[normalize-space(text())='Code verified successfully']")
	@CacheLookup
	WebElement schoolCodeVerify;

	@FindBy(xpath = "//input[@placeholder='Username']")
	@CacheLookup
	WebElement UserID;

	@FindBy(xpath = "//input[@placeholder='Password']")
	@CacheLookup
	WebElement Password;

	@FindBy(xpath = "//button[text()='LOGIN']")
	@CacheLookup
	WebElement LOGIN;

	public void schoolCode(String code) {
		schoolCodeInput.sendKeys(code);

	}

	public void submitBtn() {
		submitBtn.click();
	}

	public void SchoolCodeToastVerify() {

		String Actual = schoolCodeVerify.getText();
		System.out.println("NK"+Actual);
		Assert.assertEquals("Code verified successfully", Actual);

	}

	public void UserID(String UserName) {
		UserID.sendKeys(UserName);

	}

	public void Password(String pwd) {
		Password.sendKeys(pwd);

	}

	public void LOGINBtn() {
		LOGIN.click();
	}

}
