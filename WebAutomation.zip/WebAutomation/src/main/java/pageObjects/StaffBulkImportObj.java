package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class StaffBulkImportObj {

	WebDriver driver;

	public StaffBulkImportObj(WebDriver ldriver) {

		driver = ldriver;
		PageFactory.initElements(ldriver, this);
	}

	@FindBy(xpath = "//a[@href=\"/teachers?offset=0\"]")
	@CacheLookup
	WebElement Staff;
	
	
	@FindBy(xpath = "//button[normalize-space(text())='Import']")
	@CacheLookup
	WebElement Import;
}
