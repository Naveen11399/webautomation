package Number_Based_java_Programs;

public class swapNumbers {

	public static void main(String[] args) {

		// Swap number with 3rd variable

		int a = 10;
		int b = 20;
		System.out.println("a: " + a);
		System.out.println("b: " + b);

		int temp = a;
		a = b;
		b = temp;
		System.out.println("a: " + a);
		System.out.println("b: " + b);

		// Swap number without using 3rd variable

		int a1 = 10;
		int b1 = 20;
		System.out.println("a1: " + a1);
		System.out.println("b1: " + b1);

		a1 = a1 + b1;
		b1 = a1 - b1;
		a1 = a1 - b1;
		System.out.println("a1: " + a1);
		System.out.println("b1: " + b1);

	}

}
