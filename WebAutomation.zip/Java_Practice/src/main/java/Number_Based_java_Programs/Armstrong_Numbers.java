package Number_Based_java_Programs;

public class Armstrong_Numbers {

	public static void main(String[] args) {

		// Armstrong Number

		int num = 153;
		int temp = num;
		int arm = 0;

		while (num > 0) {
			int n = num % 10;
			arm = arm + (n * n * n);
			num /= 10;

		}

		if (arm == temp) {
			System.out.println("Armstrong Number");
		}

		else {
			System.out.println("Not a Armstrong Number");
		}

		//sum of digits

		int number=123;
		int sum=0;
		while(number>0) {

			int digit=number%10;
			sum=sum+digit;
			number /=10;
		}

		System.out.println("Sum of digits :"+sum);
	}

}
