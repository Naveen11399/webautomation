package Number_Based_java_Programs;

public class FactorialAndPrimeNumber {

	public static void main(String[] args) {

		// Factorial of number

//		int number = 5;
//
//		int temp = 5;
//		int fact = 1;
//		while (number > 0) {
//			fact = fact * number;
//			number -= 1;
//		}
//
//		System.out.println("Factorial of " + temp + " is: " + fact);
//
//		for (int i = 1; i <= number; i++) {
//			fact = fact * i;
//		}
//
//		System.out.println("Factorial of " + temp + " is: " + fact);
//	}

		// PrimeNumber

//	int prime = 12;
//	int count=0;
//	for(int i = 2;i<=prime/2;i++)
//	{
//		if (prime % i == 0) {
//			count++;
//			break;
//		}
//	}
//
//	if(count==0 & prime >1) {
//		System.out.println("prime number");
//	}
//
//	else {
//		System.out.println("Not a prime number");
//	}

		// Print the prime number 1 to 50

		for (int i = 1; i <=50; i++) {
			int count = 0;
			for (int j = 2; j <= i / 2; j++) {
				if (i % j == 0) {
					count++;
					break;
				}
			}
			if (count == 0) {
				System.out.println(i);
			}
		}
	}
}

