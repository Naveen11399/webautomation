package Number_Based_java_Programs;

public class Reverse_Number {

	public static void main(String[] args) {

		// Reversed Number

		int number = 1234;
		int rev = 0;
		while (number > 0) {
			int digit = number % 10;
			rev = rev * 10 + digit;
			number /= 10;

		}
		System.out.println("Reversed Number: " + rev);

		// Palindrome Check

		int num = 12321;
		int temp = num;
		int rev1 = 0;

		while (num > 0) {

			int digit2 = num % 10;
			rev1 = rev1 * 10 + digit2;
			num /= 10;
		}

		if (rev1 == temp) {
			System.out.println("Palindrome Number");
		} else {
			System.out.println("Not a Palindrome Number");
		}

		// Count the number

		int num1 = 12345;
		int count = 0;
		while (num1>0) {

			count++;
			num1 /= 10;

		}
		System.out.println("Number of the digits in the given number : "+count);

	}

}
