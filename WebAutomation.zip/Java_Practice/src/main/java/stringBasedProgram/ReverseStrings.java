package stringBasedProgram;

public class ReverseStrings {

	public static void main(String[] args) {

		// Method 1
		String input = "Naveenuu kumaruu";
		char ch;
		String rev = "";
		for (int i = 0; i < input.length(); i++) {
			ch = input.charAt(i);
			rev = ch + rev;
		}
		System.out.println(rev);

//Method 2	
		String rev1 = "";
		for (int i = input.length() - 1; i >= 0; i--) {
			rev1 = rev1 + input.charAt(i);
			// Method 3
//			ch = input.charAt(i);
//			rev1 = ch + rev1;
		}
		System.out.println(rev1);
	}
}
