package stringBasedProgram;

import java.util.HashMap;

public class CountOccurrencesofEach {

	public static void main(String[] args) {

		characterCount("Naveen Anisha Naveen Ice Ice");
	}

	static void characterCount(String input) {
		HashMap<String, Integer> charCountMap = new HashMap<>();
		String[] words = input.split(" ");
		for (String s : words) {
			if (charCountMap.containsKey(s)) {
				charCountMap.put(s, charCountMap.get(s) + 1);
			} else {
				charCountMap.put(s, 1);
			}
		}
		
		System.out.println("Count of Characters in a given string : "+charCountMap);
	}
}
