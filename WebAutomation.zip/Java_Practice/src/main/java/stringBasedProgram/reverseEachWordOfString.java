package stringBasedProgram;

public class reverseEachWordOfString {

	public static void main(String[] args) {

		reverseStrings("Naveen will buy the Mahindra THAR");
	}

	static void reverseStrings(String input) {

		String[] words = input.split(" ");
		String RevString = "";
		for (int i = 0; i < words.length; i++) {

			String word = words[i];
			char ch;
			String nStr="";
			for (int j = 0; j < word.length(); j++) {
				ch=word.charAt(j);
				nStr=ch+nStr;
			}
			
			RevString=RevString +nStr+" ";
		
		}
		
		System.out.println(input);
		System.out.println(RevString);
	}
}
